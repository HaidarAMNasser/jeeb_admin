/// Application Routes
class Routes {
  Routes._();

  static const String splash = '/';
  static const String onboarding = '/onboarding';
  static const String home = '/home';
  static const String login = '/login';
  static const String register = '/register';
  static const String verify = '/verify';
  static const String forgotPassword = '/forgot-password';
  static const String resetPassword = '/reset-password';
  static const String profile = '/profile';
  static const String settings = '/settings';
  static const String products = '/products';
  static const String addProduct = '/add-product';
  static const String productDetails = '/product-details';
  static const String mainNavigation = '/main-navigation';
  static const String merchants = '/merchants';
  static const String merchantDetails = '/merchant-details';
  static const String delivery = '/delivery';
  static const String deliveryDetails = '/delivery-details';
  static const String addDelivery = '/add-delivery';
  static const String orders = '/orders';
  static const String orderDetails = '/order-details';
  static const String offers = '/offers';
  static const String addOffer = '/add-offer';
  static const String offerDetails = '/offer-details';
}
